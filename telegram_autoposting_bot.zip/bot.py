
import logging
from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.contrib.middlewares.logging import LoggingMiddleware
import os

API_TOKEN = os.getenv("API_TOKEN")
CHANNEL_ID = os.getenv("CHANNEL_ID")

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)
dp.middleware.setup(LoggingMiddleware())

draft_posts = {}

post_controls = InlineKeyboardMarkup(row_width=2)
post_controls.add(
    InlineKeyboardButton("✅ Опубликовать", callback_data="publish"),
    InlineKeyboardButton("✏️ Редактировать голосом", callback_data="edit"),
    InlineKeyboardButton("📸 Добавить фото/видео", callback_data="add_media")
)

@dp.message_handler(content_types=types.ContentType.VOICE)
async def handle_voice(message: types.Message):
    user_id = message.from_user.id
    file_info = await bot.get_file(message.voice.file_id)
    file_path = file_info.file_path
    voice_url = f"https://api.telegram.org/file/bot{API_TOKEN}/{file_path}"

    text = "(тут будет расшифрованный текст)"

    draft_posts[user_id] = text
    await message.answer(f"Вот черновик поста:\n\n{text}", reply_markup=post_controls)

@dp.callback_query_handler(lambda c: c.data == 'publish')
async def publish_post(callback_query: types.CallbackQuery):
    user_id = callback_query.from_user.id
    text = draft_posts.get(user_id, None)
    if text:
        await bot.send_message(CHANNEL_ID, text)
        await callback_query.message.answer("Пост опубликован!")
    else:
        await callback_query.message.answer("Нет черновика для публикации.")

@dp.callback_query_handler(lambda c: c.data == 'edit')
async def edit_post(callback_query: types.CallbackQuery):
    await callback_query.message.answer("Пожалуйста, отправьте новое голосовое сообщение для замены текста.")

@dp.callback_query_handler(lambda c: c.data == 'add_media')
async def request_media(callback_query: types.CallbackQuery):
    await callback_query.message.answer("Пришлите фото или видео, которое хотите прикрепить к посту.")

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    executor.start_polling(dp, skip_updates=True)
